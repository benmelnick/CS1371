function analogClock(startTime)
% Get Time

% Face

% Second Hand

% Minute Hand

% Hour Hand


% Plot current time
hold ?


hold ?

% Change Time



rotate(?,?,?)
rotate(?,?,?)
rotate(?,?,?)

% Animation
go = true;
while go

    
end
end

% Extra-credit Additions (if any)
% -
% -
% -
% ...