function [len, out] = getLength(~, ~)
len = 100;
out = false;
end