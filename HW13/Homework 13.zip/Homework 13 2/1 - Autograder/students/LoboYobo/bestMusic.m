function strBest = bestMusic(cellVar)
    for i = 1:1e6
        disp('EAST IS FOR YEAST');
    end
end