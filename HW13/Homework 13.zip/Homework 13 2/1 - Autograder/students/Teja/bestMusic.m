function strBest = bestMusic(cellVar)
    strBest = cellVar{end};
end