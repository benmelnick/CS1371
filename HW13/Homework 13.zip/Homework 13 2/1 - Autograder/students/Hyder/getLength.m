function [len, logFound] = getLength(var, strDim)
    len = true;
    logFound = 'beard';
        
end