function strBest = bestMusic(in)
    strBest = 'carly rae jepsen';
    str = '';
    % str(2);
end