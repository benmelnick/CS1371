function [len, logFound] = getLength(var, strDim)
    logFound = false(100, 100);
    len = 'DEATH GRIPS IS ONLINE';
end