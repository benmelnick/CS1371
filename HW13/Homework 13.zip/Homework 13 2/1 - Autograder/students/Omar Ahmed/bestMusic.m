function strBest = bestMusic(~)
while true
    strBest = 'DEATH GRIPS';
end
end