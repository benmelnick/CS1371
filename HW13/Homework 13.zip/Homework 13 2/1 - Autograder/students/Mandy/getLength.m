function [len, logFound] = getLength(var, strDim)
    logFound = true;
    len = 'homework team teamwork makes the HOMEWORK TEAM DREAM WORK!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!';
end