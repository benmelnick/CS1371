function strBest = bestMusic(cellVar)
    strBest = 'i feel so attacked right now';
end