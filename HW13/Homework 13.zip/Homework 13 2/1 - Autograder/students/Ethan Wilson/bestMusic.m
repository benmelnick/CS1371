function strBest = bestMusic(~)
    strBest = 'during recitation my brain committed sudoku once and i had to sit down and remember where i was';
end