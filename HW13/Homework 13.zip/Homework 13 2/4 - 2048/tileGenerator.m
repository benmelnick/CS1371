%
%updatedArr = tileGenerator(arr)
%takes in a 4x4 array of doubles
%randomly generate a 2 or 4 on the board in place of a 0
%returns the input if the input array is not a 4X4 array of doubles